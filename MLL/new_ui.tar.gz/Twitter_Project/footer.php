        <!-- JAVASCRIPT START -->
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-affix.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-alert.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-button.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-carousel.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-collapse.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-dropdown.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-tooltip.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-popover.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-scrollspy.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-tab.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-transition.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>bootstrap-typeahead.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>highstock.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>modules/exporting.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>jquery.tablesorter.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>jquery.awesomeCloud-0.2.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>jquery-ui-1.10.3.custom.min.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>purl.js"></script>
        <script type="text/javascript" src="<?php echo $this->js_path; ?>jquery-ui-timepicker-addon.js"></script>
        <!--<script type="text/javascript" src="<?php echo $this->js_path; ?>wordcloud2.js"></script>-->
        
        <!-- App JS initialization START -->
        <script type="text/javascript">
                var app = new App();
                app.init();
        </script>
        <!-- App JS initialization END -->
        
        <!-- JAVASCRIPT END -->

</html>