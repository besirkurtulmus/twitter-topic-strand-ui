<!-- topReTweet Modal 1 -->
<div style="height: 550px;" id="topReTweetModal-1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="topReTweetModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Top reTweets</h3>
  </div>
  <div class="row-fluid modal-body topReTweetBody-1" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="topReTweetTable-1"></table>
  </div>
</div>
<!-- topReTweet Modal 2 -->
<div style="height: 550px;" id="topReTweetModal-2" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="topReTweetModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Top reTweets</h3>
  </div>
  <div class="row-fluid modal-body topReTweetBody-2" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="topReTweetTable-2"></table>
  </div>
</div>