<!-- missUserID Modal 1 -->
<div style="height: 550px;" id="missUserIDModal-1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="heroUserIDModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Missionary User IDs</h3>
  </div>
  <div class="row-fluid modal-body missUserIDBody-1" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="missUserIDTable-1"></table>
  </div>
</div>
<!-- missUserID Modal 2 -->
<div style="height: 550px;" id="missUserIDModal-2" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="heroUserIDModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Missionary User IDs</h3>
  </div>
  <div class="row-fluid modal-body missUserIDBody-2" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="missUserIDTable-2"></table>
  </div>
</div>