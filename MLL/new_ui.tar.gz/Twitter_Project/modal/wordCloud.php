<!-- wordCloud Modal 1 -->
<div id="wordCloudModal-1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="wordCloudModalLabel" aria-hidden="true">
  <div class="row-fluid modal-body wordCloudBody-1" style="width: 95%; height: 100%;">
      <div class="wordCloud-larger"></div>
  </div>
</div>