<!-- heroUserID Modal 1 -->
<div style="height: 550px;" id="heroUserIDModal-1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="heroUserIDModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Noisy User IDs</h3>
  </div>
  <div class="row-fluid modal-body heroUserIDBody-1" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="heroUserIDTable-1"></table>
  </div>
</div>