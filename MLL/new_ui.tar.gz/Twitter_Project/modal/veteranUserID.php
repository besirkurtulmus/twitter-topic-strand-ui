<!-- veteranUserID Modal 1 -->
<div style="height: 550px;" id="veteranUserIDModal-1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="veteranUserIDModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Veteran User IDs</h3>
  </div>
  <div class="row-fluid modal-body veteranUserIDBody-1" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="veteranUserIDTable-1"></table>
  </div>
</div>
<!-- veteranUserID Modal 2 -->
<div style="height: 550px;" id="veteranUserIDModal-2" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="veteranUserIDModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Veteran User IDs</h3>
  </div>
  <div class="row-fluid modal-body veteranUserIDBody-2" style="width: 95%; height: 80%;">
      <table class="table table-striped table-bordered" id="veteranUserIDTable-2"></table>
  </div>
</div>